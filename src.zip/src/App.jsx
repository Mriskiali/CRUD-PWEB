import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
// import "./App.css";
import LoginForm from "./login";
import RegisterForm from "./register";

function App() {
  return (
    <Router>
      <div className="App">
        <nav>
          <Link to={"/login"}>Login</Link>
          <Link to={"/register"}>Register</Link>
        </nav>
        <Routes>
          <Route path="/login" element={<LoginForm />} />
          <Route path="/register" element={<RegisterForm />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
